import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "in.retailindia.app",
  appName: "Retail India",
  webDir: "dist",
  server: { androidScheme: "https" },
};

export default config;
