# RETAIL INDIA — production application starter

A shared React + TypeScript application for the Retail India B2B medicine marketplace. The same web build is packaged for Android using Capacitor.

## Included

- Retailer and stockist login/registration with role checks
- Hashed passwords (bcrypt), signed 12-hour JWT sessions, Helmet, CORS and API rate limiting
- PostgreSQL data model for users, medicines, orders and order items
- Retailer catalogue, MOQ-aware cart, checkout and order history
- Stockist inventory entry and order status updates
- Pending account status by default; retailer ordering is blocked until an authorised approval process changes the status
- Responsive website and Capacitor Android wrapper

## Not yet included / launch blockers

This is a production-oriented foundation, not a certified or fully launched commerce service. Before public launch, add a controlled admin/compliance portal for verifying licences, document upload with private object storage, audit logs, account recovery/MFA, email/SMS OTP, payment gateway integration and webhook verification, delivery integration, tax invoice/GST handling, privacy/terms/retention policies, monitoring/backups, security testing and operational support. The licence desk currently intentionally does not auto-approve anyone. Joint-buying and public store directory are placeholders pending consent, supplier agreements and anti-abuse controls. Do not treat sample catalogue data or test accounts as real suppliers, stock or verified businesses.

Discounts in the interface are illustrative. Confirm commercial rules, tax treatment, scheme terms and supplier contracts before enabling them. No payment is processed by this starter.

## Requirements

- Node.js 20+
- npm
- Docker Desktop / Docker Engine (for local PostgreSQL)
- Android Studio + Android SDK (for APK build)

## 1. Configure

Copy root `.env.example` to `.env` and `server/.env.example` to `server/.env`. Set `JWT_SECRET` to a unique random value of at least 32 characters. For production, use a managed PostgreSQL database and a secret manager; never commit `.env`.

Set root `.env`:
```
VITE_API_URL=http://localhost:4000/api
```

Set `server/.env`:
```
DATABASE_URL=postgresql://retail:retail_password@localhost:5432/retailindia?schema=public
JWT_SECRET=your-long-random-secret-value-at-least-32-characters
PORT=4000
CLIENT_ORIGIN=http://localhost:5173
```

## 2. Start database and API

From project root:
```
docker compose up -d db
cd server
npm install
npx prisma generate
npx prisma migrate dev --name initial
npm run dev
```

For a first migration, `migrate dev` creates the migration file. In deployment use `npx prisma migrate deploy`, not `migrate dev`.

## 3. Start website

In another terminal from project root:
```
npm install
npm run dev
```
Open `http://localhost:5173`. The API runs on `http://localhost:4000`.

New accounts are PENDING. For local development only, approve a test account using Prisma Studio:
```
cd server
npx prisma studio
```
Open the User table and set `status` to `APPROVED` for the test retailer. Build a proper admin review workflow before production. Do not approve accounts without validating licences and business identity.

## 4. Production website deployment

1. Provision managed PostgreSQL with backups, encryption and restricted network access.
2. Deploy `server/` to a Node hosting provider (container or Node service). Configure `DATABASE_URL`, strong `JWT_SECRET`, `PORT`, and exact production `CLIENT_ORIGIN`.
3. Run `npx prisma migrate deploy` during release.
4. Build the frontend with `VITE_API_URL=https://api.your-domain.example/api npm run build`.
5. Deploy `dist/` to a static host/CDN and configure SPA fallback to `index.html`.
6. Enforce HTTPS, secure headers, monitoring, backups and restore drills. Restrict CORS to the exact website origin(s).

## 5. Android APK build

The Android app is a WebView wrapper around the same responsive React app. It needs the production HTTPS API URL at build time.

```
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio: allow Gradle sync, choose Build > Generate Signed Bundle / APK > APK, create and securely store a release keystore, select release, then build. The output is normally under `android/app/build/outputs/apk/release/`. For Google Play, generate an Android App Bundle (AAB) instead and complete Play Console testing and declarations.

If you already ran `cap add android`, do not run it again; use `npx cap sync android`.

## Security / compliance notes

- JWT currently lives in browser localStorage in this starter. For a hardened web deployment consider secure, HttpOnly, SameSite cookies with CSRF protection; for native builds use a secure device token store.
- Add admin-only audited licence approval and document review before real wholesale medicine transactions.
- Confirm applicable Indian drug-sale, e-pharmacy/marketplace, GST, consumer-protection, privacy and payment requirements with qualified legal/compliance professionals before operating.
- Validate prescription/regulated-product rules and stockist/retailer eligibility at both UI and API layers.
- Add automated tests, dependency scanning, penetration testing and incident response before handling real customer data.

## API overview

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/medicines`
- `POST /api/medicines` (stockist)
- `POST /api/orders` (approved retailer)
- `GET /api/orders`
- `PATCH /api/orders/:id/status` (assigned stockist / admin)
- `GET /api/health`

No demo password or automatic licence verification is built in.


## Production phase 2: admin console and manual UPI

- Admin console build entry: `/admin.html` (publish as `https://admin.retailindia.com` using a separate static-site project/build with the same source and `VITE_API_URL`).
- Configure `ADMIN_EMAIL` and a one-time `ADMIN_SETUP_TOKEN` in the API secret manager. Call `POST /api/admin/bootstrap` once with header `x-admin-setup-token` and JSON `{ "name": "Owner", "email": "the-configured-admin-email", "password": "a-long-unique-password" }`. Immediately remove `ADMIN_SETUP_TOKEN` from the environment and redeploy. Admin login is available only through the admin console; public registration cannot create admins.
- Manual UPI payment records are created for UPI orders. Retailers submit a UTR using `POST /api/payments/:id/utr`; admins reconcile against the bank statement and use `PATCH /api/admin/payments/:id/review` to verify/reject. UTR submission is not proof of receipt.
- Set `MERCHANT_UPI_ID` only after the merchant confirms the exact VPA and account-holder name. Until then, checkout must not display a payment QR or mark an order paid.
- Apply the new Prisma migration: `cd server && npx prisma migrate dev --name admin_manual_upi` locally, commit the generated migration, then run `npx prisma migrate deploy` in production.
- Set production website build variable `VITE_API_URL=https://api.retailindia.com/api`. Admin static build can be served on its own host/domain from the same `dist/admin.html` entry, with SPA fallback as required.

### Manual UPI release gate

This code establishes a manual reconciliation record and admin review endpoints; it does not yet render a merchant-specific QR/deep link, attach payment to the retailer order UI, or automatically read bank credits. Do not announce online payment acceptance until the verified merchant VPA is supplied and the retailer payment instructions/UTR submission UI are completed and tested.


## RETAIL INDIA production target (2026-10-03)

The selected target domain is `retailindia.com`; first admin email is `parveenkaushik787677@gmail.com`; merchant UPI VPA is `pndtpina-2@okhdfcbank`. See [AWS-DEPLOYMENT.md](./AWS-DEPLOYMENT.md) for the proposed managed AWS Mumbai deployment, environment configuration, domain routing and release gates. The domain must still be purchased/verified and no cloud resources have been provisioned by this repository change.
