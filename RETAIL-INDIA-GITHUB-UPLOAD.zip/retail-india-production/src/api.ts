const API = import.meta.env.VITE_API_URL || "http://localhost:4000/api";
export async function api<T>(path:string, options:RequestInit={}):Promise<T>{
 const token=localStorage.getItem("ri_token");
 const response=await fetch(`${API}${path}`,{...options,headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`} : {}),...options.headers}});
 const data=await response.json().catch(()=>({message:"Unexpected server response"}));
 if(!response.ok) throw new Error(data.message||"Request failed");
 return data as T;
}
